"""
audit_missing.py — reconcile input files vs parsed outputs vs the ledger.

For every input file it answers: does a parsed output exist, and if not, WHY?

Categories reported:
  OK                    output exists (current naming)
  OK_OLD_NAMING         output exists only under the old stem-based naming
                        (pre-collision-fix era, e.g. report.json instead of
                        report.pdf.json) — may be a collision victim's winner
  NO_PARSER_EXT         extension has no parser mapped in config.yaml
  PRODUCT_CODE          in a Product Code folder — excluded by design
  NEVER_ATTEMPTED       not in the ledger at all — pipeline never got to it
                        (e.g. old timeout loop, or added after last run)
  LEDGER_ERROR          ledger status "error" — retrying; last_error included
  LEDGER_FAILED         dead-lettered after max attempts; last_error included
  DONE_BUT_NO_OUTPUT    ledger says done but no output found under either
                        naming — likely overwritten by a name collision

Usage:
  pip install google-cloud-storage pyyaml
  gcloud auth application-default login   # or run with the pipeline SA
  python audit_missing.py                 # writes audit_report.csv

Only needs google-cloud-storage + pyyaml — safe to run from your laptop.
Read-only: it never writes to the bucket.
"""

import csv
import json
import re
import sys
from collections import Counter
from urllib.parse import unquote

import yaml


def load_cfg(path="config.yaml"):
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def ext_of(name: str) -> str:
    return ("." + name.rsplit(".", 1)[-1]).lower() if "." in name else ""


def is_product_code_path(blob_name: str) -> bool:
    for segment in blob_name.split("/")[:-1]:
        norm = re.sub(r"[^a-z0-9]", "", unquote(segment).lower())
        if "product" in norm and "code" in norm:
            return True
    return False


def expected_outputs(rel: str, parser_type: str, input_prefix: str, parsed_prefix: str):
    """Return (new_naming_path, old_naming_path) for an input file."""
    suffix = "_extracted.json" if parser_type == "excel" else ".json"
    new_path = input_prefix + parsed_prefix + rel + suffix
    stem = rel.rsplit(".", 1)[0] if "." in rel else rel
    old_path = input_prefix + parsed_prefix + stem + suffix
    return new_path, old_path


def main():
    cfg = load_cfg()
    bucket_name = cfg["gcs"]["destination_bucket"]
    input_prefix = cfg["gcs"]["input_prefix"]
    parsed_prefix = cfg["gcs"]["parsed_prefix"]
    state_blob = cfg["state"]["tracker_blob"]

    ext_map = {}
    for ptype, exts in cfg["supported_extensions"].items():
        for e in exts:
            ext_map[e.lower()] = ptype

    from google.cloud import storage
    client = storage.Client(
        project=cfg["gcs"].get("destination_project_id")
        or cfg["gcp"]["project_id"]
    )
    bucket = client.bucket(bucket_name)

    print(f"Listing gs://{bucket_name}/{input_prefix} ...")
    all_blobs = [b.name for b in bucket.list_blobs(prefix=input_prefix)]

    own_output_prefix = input_prefix + parsed_prefix
    outputs = {n for n in all_blobs if n.startswith(own_output_prefix)}
    inputs = [
        n for n in all_blobs
        if not n.startswith(own_output_prefix) and not n.endswith("/")
    ]
    print(f"  {len(inputs)} input file(s), {len(outputs)} parsed output(s)")

    # Ledger (handles both v1 flat and v2 formats)
    ledger = {}
    state_raw = bucket.get_blob(state_blob)
    if state_raw:
        data = json.loads(state_raw.download_as_bytes())
        entries = data.get("files", data) if isinstance(data, dict) else {}
        for name, val in entries.items():
            if name == "version":
                continue
            ledger[name] = val if isinstance(val, dict) else {"status": "done"}
    print(f"  {len(ledger)} ledger entrie(s)")

    rows, counts = [], Counter()
    for name in sorted(inputs):
        rel = name[len(input_prefix):]
        ext = ext_of(name)
        ptype = ext_map.get(ext)
        entry = ledger.get(name)

        if is_product_code_path(name):
            cat, detail = "PRODUCT_CODE", "excluded by design"
        elif ptype is None:
            cat, detail = "NO_PARSER_EXT", f"extension {ext or '(none)'}"
        else:
            new_out, old_out = expected_outputs(
                rel, ptype, input_prefix, parsed_prefix
            )
            if new_out in outputs:
                cat, detail = "OK", new_out
            elif old_out in outputs:
                cat, detail = "OK_OLD_NAMING", old_out
            elif entry is None:
                cat, detail = "NEVER_ATTEMPTED", "not in ledger"
            elif entry.get("status") == "failed":
                cat = "LEDGER_FAILED"
                detail = f"attempts={entry.get('attempts')} last_error={entry.get('last_error', '')[:200]}"
            elif entry.get("status") == "error":
                cat = "LEDGER_ERROR"
                detail = f"attempts={entry.get('attempts')} last_error={entry.get('last_error', '')[:200]}"
            else:
                cat, detail = "DONE_BUT_NO_OUTPUT", "likely name-collision victim"

        counts[cat] += 1
        rows.append({"file": name, "category": cat, "detail": detail})

    with open("audit_report.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["file", "category", "detail"])
        w.writeheader()
        w.writerows(rows)

    # ---- per-folder rollup: which synced folders have ZERO outputs? ----
    # (GCS has no real folders — a folder appears under parsed_files/ only
    # when at least one output is written into it. A missing folder means
    # every file inside it fell into a non-OK category.)
    import posixpath
    folders = {}
    for r in rows:
        folder = posixpath.dirname(r["file"]) or "(root)"
        folders.setdefault(folder, Counter())[r["category"]] += 1

    folder_rows = []
    for folder, cats in sorted(folders.items()):
        total = sum(cats.values())
        ok = cats.get("OK", 0) + cats.get("OK_OLD_NAMING", 0)
        dominant = ", ".join(f"{c}={n}" for c, n in cats.most_common(3))
        folder_rows.append({
            "folder": folder,
            "files": total,
            "with_output": ok,
            "missing": total - ok,
            "breakdown": dominant,
        })

    with open("audit_folders.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(
            fh, fieldnames=["folder", "files", "with_output", "missing", "breakdown"]
        )
        w.writeheader()
        w.writerows(folder_rows)

    zero_output = [f for f in folder_rows if f["with_output"] == 0]
    print(f"\n===== FOLDERS WITH ZERO OUTPUTS ({len(zero_output)}) =====")
    for f in zero_output[:40]:
        print(f"  {f['folder']}  ({f['files']} file(s))  ->  {f['breakdown']}")
    if len(zero_output) > 40:
        print(f"  ... and {len(zero_output) - 40} more (see audit_folders.csv)")

    print("\n===== SUMMARY =====")
    for cat, n in counts.most_common():
        print(f"  {cat:22s} {n}")
    missing = sum(
        n for c, n in counts.items() if c not in ("OK", "OK_OLD_NAMING")
    )
    print(f"\n  Total without a current output: {missing}")
    print("  Per-file detail:   audit_report.csv")
    print("  Per-folder rollup: audit_folders.csv")


if __name__ == "__main__":
    sys.exit(main())
