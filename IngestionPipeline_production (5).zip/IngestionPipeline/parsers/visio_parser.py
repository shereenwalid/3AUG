"""
parsers/visio_parser.py

Extracts text from Visio .vsdx / .vsdm files. Both are OPC zip packages
containing page XML under visio/pages/ — shape text lives in <Text>
elements, so no third-party Visio library is needed.
"""

import io
import json
import logging
import posixpath
import zipfile
import xml.etree.ElementTree as ET
from typing import Dict, Any, List

from utils.gemini_client import GeminiClient, GENERIC_JSON_PROMPT

logger = logging.getLogger(__name__)


class VisioParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        try:
            texts = self._extract_page_texts(file_bytes)
        except (zipfile.BadZipFile, ET.ParseError) as exc:
            logger.exception("[Visio] Unreadable file %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable Visio file",
            }

        combined = "\n\n".join(texts)
        logger.info(
            "[Visio] %s — %d page(s), %d chars extracted",
            filename, len(texts), len(combined),
        )

        if not combined.strip():
            return {
                "_meta": {"source_file": filename, "page_count": len(texts)},
                "error": "No extractable text in diagram",
            }

        raw = self.gemini.extract_from_text(combined, GENERIC_JSON_PROMPT)
        result = self._safe_parse_json(raw, filename)
        result["_meta"] = {
            "source_file": filename,
            "page_count": len(texts),
            "char_count": len(combined),
        }
        return result

    @staticmethod
    def _extract_page_texts(file_bytes: bytes) -> List[str]:
        texts: List[str] = []
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            page_xmls = sorted(
                n for n in zf.namelist()
                if n.startswith("visio/pages/") and n.endswith(".xml")
                and posixpath.basename(n).startswith("page")
            )
            for name in page_xmls:
                root = ET.fromstring(zf.read(name))
                shape_lines: List[str] = []
                for el in root.iter():
                    # Namespace-agnostic match on <Text> elements
                    if el.tag.rsplit("}", 1)[-1] == "Text":
                        content = "".join(el.itertext()).strip()
                        if content:
                            shape_lines.append(content)
                header = f"--- {posixpath.basename(name)} ---"
                texts.append("\n".join([header] + shape_lines))
        return texts

    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        try:
            return json.loads(raw.strip())
        except json.JSONDecodeError:
            logger.warning("[Visio] Could not parse JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}
