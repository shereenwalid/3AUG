"""
parsers/email_parser.py

Parses Outlook .msg email files.

Workflow:
  1. Extract email metadata + body text
  2. Send to Gemini for structured JSON extraction
  3. Return any attachments so the pipeline router can parse them too
"""

import io
import json
import logging
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple

from utils.gemini_client import GeminiClient, EMAIL_JSON_PROMPT

logger = logging.getLogger(__name__)


@dataclass
class Attachment:
    filename: str
    data: bytes
    mime_type: str


class EmailParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(
        self, file_bytes: bytes, filename: str
    ) -> Tuple[Dict[str, Any], List[Attachment]]:
        """
        Parse a .msg (Outlook OLE) or .eml (MIME) file.

        Returns:
          - result:      structured JSON dict saved to GCS
          - attachments: list of attachments to route through their own parsers
        """
        # OLE files start with d0cf11e0; anything else with a .eml name (or
        # a mislabeled .msg that is really MIME) goes through the stdlib
        # email parser.
        if filename.lower().endswith(".eml") or not file_bytes.startswith(
            b"\xd0\xcf\x11\xe0"
        ):
            email_text, attachments = self._read_eml(file_bytes)
        else:
            email_text, attachments = self._read_msg(file_bytes)

        logger.info(
            "[Email] %s — body %d chars, %d attachment(s)",
            filename, len(email_text), len(attachments),
        )

        raw = self.gemini.extract_from_text(email_text, EMAIL_JSON_PROMPT)
        result = self._safe_parse_json(raw, filename)
        result["_meta"] = {
            "source_file": filename,
            "attachment_count": len(attachments),
            "attachment_names": [a.filename for a in attachments],
        }
        return result, attachments

    def _read_msg(self, file_bytes: bytes) -> Tuple[str, List[Attachment]]:
        import extract_msg  # lazy import

        msg = extract_msg.Message(io.BytesIO(file_bytes))

        email_text = "\n".join([
            f"From: {msg.sender or ''}",
            f"To: {msg.to or ''}",
            f"CC: {msg.cc or ''}",
            f"Subject: {msg.subject or ''}",
            f"Date: {msg.date or ''}",
            "",
            "--- BODY ---",
            msg.body or "",
        ])

        attachments: List[Attachment] = []
        for att in msg.attachments:
            att_data = att.data
            att_name = att.longFilename or att.shortFilename or "attachment"
            if att_data:
                attachments.append(
                    Attachment(
                        filename=att_name,
                        data=att_data,
                        mime_type=self._guess_mime(att_name),
                    )
                )

        msg.close()
        return email_text, attachments

    def _read_eml(self, file_bytes: bytes) -> Tuple[str, List[Attachment]]:
        """Parse RFC-822 .eml via the stdlib — no extra dependency."""
        import email
        from email import policy

        msg = email.message_from_bytes(file_bytes, policy=policy.default)

        body = ""
        body_part = msg.get_body(preferencelist=("plain", "html"))
        if body_part is not None:
            try:
                body = body_part.get_content()
            except Exception:
                payload = body_part.get_payload(decode=True) or b""
                body = payload.decode("utf-8", errors="replace")

        email_text = "\n".join([
            f"From: {msg.get('From', '')}",
            f"To: {msg.get('To', '')}",
            f"CC: {msg.get('Cc', '')}",
            f"Subject: {msg.get('Subject', '')}",
            f"Date: {msg.get('Date', '')}",
            "",
            "--- BODY ---",
            body,
        ])

        attachments: List[Attachment] = []
        for part in msg.iter_attachments():
            att_name = part.get_filename() or "attachment"
            data = part.get_payload(decode=True)
            if data:
                attachments.append(
                    Attachment(
                        filename=att_name,
                        data=data,
                        mime_type=part.get_content_type()
                        or self._guess_mime(att_name),
                    )
                )
        return email_text, attachments


    @staticmethod
    def _guess_mime(filename: str) -> str:
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        return {
            "pdf":  "application/pdf",
            "png":  "image/png",
            "jpg":  "image/jpeg",
            "jpeg": "image/jpeg",
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "xls":  "application/vnd.ms-excel",
            "csv":  "text/csv",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "doc":  "application/msword",
            "msg":  "application/vnd.ms-outlook",
        }.get(ext, "application/octet-stream")

    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        try:
            clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("[Email] Could not parse JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}
