import io
import logging
from typing import Dict, Any, List, Optional, Set

import pandas as pd
from openpyxl import load_workbook

from utils.gemini_client import GeminiClient, EXCEL_LAYOUT_PROMPT

logger = logging.getLogger(__name__)

# Safety valve: if a workbook has more non-empty cells than this, don't send
# it to Gemini cell-by-cell — fall back to a straight pandas table load.

MAX_CELLS_FOR_GEMINI = 50000
MAX_CHARS_FOR_GEMINI = 100000

class ExcelParser:
    def __init__(self, gemini: Optional[GeminiClient] = None,
                 max_cells_for_gemini: int = MAX_CELLS_FOR_GEMINI):
        self.gemini = gemini
        self.max_cells_for_gemini = max_cells_for_gemini


    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """
        Parse an Excel file and return a structured JSON summary.
        All extracted data (tables and forms) is returned as JSON for
        the caller to save to GCS — no BigQuery insertion is performed.
        """
        # openpyxl (used by _dump_cells) cannot open legacy .xls at all —
        # previously these came back as "Empty or unreadable". Same for
        # binary .xlsb. CSV isn't a workbook — load it directly. .xlsm
        # works fine on the normal openpyxl path.
        lower = filename.lower()
        if lower.endswith(".csv"):
            logger.info("[Excel] %s — CSV, using direct pandas load", filename)
            return self._csv_load(file_bytes, filename)
        if lower.endswith((".xls", ".xlsb")):
            logger.info(
                "[Excel] %s — legacy/binary workbook, using direct pandas load",
                filename,
            )
            return self._fallback_table_load(file_bytes, filename)

        cells = self._dump_cells(file_bytes, filename)
        if not cells:
            logger.warning("[Excel] Empty or unreadable file: %s", filename)
            return {
                "_meta": {"source_file": filename, "rows_inserted": 0},
                "error": "Empty or unreadable file",
            }

        if self.gemini is None or len(cells) > self.max_cells_for_gemini:
            logger.info(
                "[Excel] %s — %d cells, skipping Gemini (no client or over "
                "%d-cell threshold), falling back to direct table load",
                filename, len(cells), self.max_cells_for_gemini,
            )
            return self._fallback_table_load(file_bytes, filename)
        
        try:
            structure = self._classify_with_gemini(cells, filename)
            return self._route_blocks(structure, filename)

        except Exception as exc:
            logger.warning(
                "[Excel] %s - Gemini failed (%s), using fallback load",
                filename,
                exc,
            )

            return self._fallback_table_load(
                file_bytes,
                filename,
            )

        # structure = self._classify_with_gemini(cells, filename)
        # return self._route_blocks(structure, filename)


    def _dump_cells(self, file_bytes: bytes, filename: str) -> List[str]:
        """
        Read every non-empty cell from every sheet and represent it as a
        position-tagged line: "[sheet_name] R<row>C<col>: <value>".

        This makes no assumption about where data starts, whether columns
        line up across sheets, or whether a sheet holds one table or five.
        """
        try:
            wb = load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=True)
        except Exception as exc:
            logger.exception("[Excel] Failed to open workbook %s: %s", filename, exc)
            return []

        lines: List[str] = []
        skipped: List[str] = []
        for sheet in wb.worksheets:
            # Excel marks sheets "visible", "hidden", or "veryHidden".
            # Hidden sheets are usually working/scratch data the user does
            # not consider part of the document — extracting them produced
            # rows that appear nowhere in the visible workbook.
            if sheet.sheet_state != "visible":
                skipped.append(f"{sheet.title}({sheet.sheet_state})")
                continue
            for row in sheet.iter_rows():
                for cell in row:
                    value = cell.value
                    if value is None:
                        continue
                    text = str(value).strip()
                    if not text:
                        continue
                    lines.append(f"[{sheet.title}] R{cell.row}C{cell.column}: {text}")
        if skipped:
            logger.info(
                "[Excel] %s — skipped %d hidden sheet(s): %s",
                filename, len(skipped), ", ".join(skipped),
            )
        wb.close()
        return lines


    # def _classify_with_gemini(self, cells: List[str], filename: str) -> Dict[str, Any]:
    #     dump_text = "\n".join(cells)
    #     raw = self.gemini.extract_from_text(dump_text, EXCEL_LAYOUT_PROMPT)
    #     return self._safe_parse_json(raw, filename)

    def _classify_with_gemini(self, cells: List[str], filename: str) -> Dict[str, Any]:
        dump_text = "\n".join(cells)

        logger.info(
            "[Excel] %s - %s cells, %s chars sent to Gemini",
            filename,
            len(cells),
            len(dump_text),
        )

        if len(dump_text) > MAX_CHARS_FOR_GEMINI:
            logger.info(
                "[Excel] %s - dump too large (%s chars), using fallback load",
                filename,
                len(dump_text),
            )
            raise ValueError("EXCEL_TOO_LARGE_FOR_GEMINI")

        raw = self.gemini.extract_from_text(
            dump_text,
            EXCEL_LAYOUT_PROMPT,
        )

        return self._safe_parse_json(raw, filename)


    def _route_blocks(self, structure: Dict[str, Any], filename: str) -> Dict[str, Any]:
        sheets = structure.get("sheets", [])
        if not sheets and "raw_extraction" in structure:
            return {
                "_meta": {"source_file": filename},
                "error": "Could not interpret sheet structure",
                "raw_extraction": structure["raw_extraction"],
            }

        form_blocks: List[Dict[str, Any]] = []
        table_blocks: List[Dict[str, Any]] = []

        for sheet in sheets:
            sheet_name = sheet.get("sheet_name", "Sheet1")
            for block in sheet.get("blocks", []):
                layout = block.get("layout")

                if layout == "table" and block.get("rows"):
                    table_blocks.append({
                        "sheet_name": sheet_name,
                        "title": block.get("title"),
                        "rows": block.get("rows"),
                        "notes": block.get("notes"),
                    })

                elif layout == "form" and block.get("fields"):
                    form_blocks.append({
                        "sheet_name": sheet_name,
                        "title": block.get("title"),
                        "fields": block.get("fields"),
                        "notes": block.get("notes"),
                    })

                else:
                    logger.warning(
                        "[Excel] %s — block on sheet '%s' had layout=%r with no "
                        "usable data, skipping",
                        filename, sheet_name, layout,
                    )

        summary: Dict[str, Any] = {
            "_meta": {
                "source_file": filename,
                "form_block_count": len(form_blocks),
                "table_block_count": len(table_blocks),
                "confidence": structure.get("confidence"),
            }
        }
        if form_blocks:
            summary["forms"] = form_blocks
        if table_blocks:
            summary["tables"] = table_blocks

        logger.info(
            "[Excel] %s — %d form block(s), %d table block(s) written as JSON",
            filename, len(form_blocks), len(table_blocks),
        )
        return summary


    def _visible_sheet_names(
        self, file_bytes: bytes, filename: str
    ) -> Optional[Set[str]]:
        """Return the set of VISIBLE sheet names, or None if visibility
        can't be determined (caller then falls back to reading all sheets).

        Each format stores visibility differently:
          .xlsx/.xlsm  openpyxl exposes ws.sheet_state
          .xls         xlrd exposes sheet.visibility (0 = visible)
          .xlsb        pyxlsb exposes no visibility API, so read the
                       BrtBundleSh records out of xl/workbook.bin directly
        """
        lower = filename.lower()
        try:
            if lower.endswith((".xlsx", ".xlsm")):
                wb = load_workbook(
                    io.BytesIO(file_bytes), read_only=True, data_only=True
                )
                names = {
                    ws.title for ws in wb.worksheets
                    if ws.sheet_state == "visible"
                }
                wb.close()
                return names

            if lower.endswith(".xls"):
                import xlrd
                book = xlrd.open_workbook(file_contents=file_bytes)
                # visibility: 0 = visible, 1 = hidden, 2 = "very hidden"
                return {
                    sh.name for sh in book.sheets()
                    if getattr(sh, "visibility", 0) == 0
                }

            if lower.endswith(".xlsb"):
                return self._xlsb_visible_sheets(file_bytes)
        except Exception as exc:
            logger.warning(
                "[Excel] Could not determine sheet visibility for %s (%s) — "
                "processing all sheets", filename, exc,
            )
        return None

    @staticmethod
    def _xlsb_visible_sheets(file_bytes: bytes) -> Optional[Set[str]]:
        """Parse sheet visibility from an .xlsb workbook part.

        .xlsb is a zip whose xl/workbook.bin holds BrtBundleSh records
        (record type 156): [4-byte state][4-byte id][4-byte rel-id len +
        UTF-16LE][4-byte name len + UTF-16LE]. state 0 = visible.
        Records use variable-length ids and sizes, so walk the stream.
        """
        import zipfile
        import struct

        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            if "xl/workbook.bin" not in zf.namelist():
                return None
            data = zf.read("xl/workbook.bin")

        visible: Set[str] = set()
        pos, n = 0, len(data)
        while pos < n:
            # Variable-length record id (1-2 bytes, high bit = continue)
            b = data[pos]; pos += 1
            rec_id = b & 0x7F
            if b & 0x80:
                if pos >= n:
                    break
                b2 = data[pos]; pos += 1
                rec_id |= (b2 & 0x7F) << 7
            # Variable-length record size (1-4 bytes)
            size, shift = 0, 0
            for _ in range(4):
                if pos >= n:
                    return visible or None
                b = data[pos]; pos += 1
                size |= (b & 0x7F) << shift
                if not (b & 0x80):
                    break
                shift += 7
            payload = data[pos: pos + size]
            pos += size

            if rec_id == 156 and len(payload) >= 12:   # BrtBundleSh
                state = struct.unpack_from("<I", payload, 0)[0]
                off = 8
                rel_len = struct.unpack_from("<I", payload, off)[0]
                off += 4
                if rel_len != 0xFFFFFFFF:
                    off += rel_len * 2
                if off + 4 > len(payload):
                    continue
                name_len = struct.unpack_from("<I", payload, off)[0]
                off += 4
                name = payload[off: off + name_len * 2].decode(
                    "utf-16-le", errors="replace"
                )
                if state == 0:      # 0 visible, 1 hidden, 2 very hidden
                    visible.add(name)
        return visible or None

    def _fallback_table_load(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        # openpyxl only reads .xlsx/.xlsm; legacy .xls needs xlrd, binary
        # .xlsb needs pyxlsb.
        lower = filename.lower()
        if lower.endswith(".xls"):
            engine = "xlrd"
        elif lower.endswith(".xlsb"):
            engine = "pyxlsb"
        else:
            engine = "openpyxl"
        try:
            sheets = pd.read_excel(io.BytesIO(file_bytes), sheet_name=None, engine=engine)
        except Exception as exc:
            logger.exception("[Excel] Fallback load failed for %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable file",
            }

        visible = self._visible_sheet_names(file_bytes, filename)
        hidden_skipped: List[str] = []
        table_blocks: List[Dict[str, Any]] = []

        for sheet_name, df in sheets.items():
            if visible is not None and sheet_name not in visible:
                hidden_skipped.append(sheet_name)
                continue
            if df is None or df.empty:
                continue
            df = self._clean_dataframe(df, filename, sheet_name, title=None)
            table_blocks.append({
                "sheet_name": sheet_name,
                "title": None,
                "rows": self._json_safe_records(df),
                "notes": None,
            })

        summary: Dict[str, Any] = {
            "_meta": {
                "source_file": filename,
                "table_block_count": len(table_blocks),
                "parse_strategy": "fallback_direct_load",
                "hidden_sheets_skipped": hidden_skipped,
                "sheet_visibility_known": visible is not None,
            }
        }
        if hidden_skipped:
            logger.info(
                "[Excel] %s — skipped %d hidden sheet(s): %s",
                filename, len(hidden_skipped), ", ".join(hidden_skipped),
            )
        if table_blocks:
            summary["tables"] = table_blocks

        logger.info(
            "[Excel] %s — fallback load produced %d table block(s) as JSON",
            filename, len(table_blocks),
        )
        return summary


    def _csv_load(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """Load a CSV into the same table-blocks shape as workbook output."""
        try:
            df = pd.read_csv(
                io.BytesIO(file_bytes),
                sep=None, engine="python",       # sniff , ; \t delimiters
                encoding_errors="replace",
            )
        except Exception as exc:
            logger.exception("[Excel] CSV load failed for %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable file",
            }

        if df.empty:
            return {"_meta": {"source_file": filename}, "error": "Empty file"}

        df = self._clean_dataframe(df, filename, "csv", title=None)
        return {
            "_meta": {
                "source_file": filename,
                "table_block_count": 1,
                "parse_strategy": "pandas_csv",
            },
            "tables": [{
                "sheet_name": "csv",
                "title": None,
                "rows": self._json_safe_records(df),
                "notes": None,
            }],
        }

    @staticmethod
    def _json_safe_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        df.to_dict(orient="records") yields pd.Timestamp / NaT / NaN values
        that json.dumps cannot serialize (this is what made large workbooks
        'disappear' — the upload crashed after a successful parse).
        Round-tripping through pandas' own JSON encoder converts
        Timestamps to ISO strings and NaN/NaT to null.

        Null keys are then dropped from each record: a spreadsheet row only
        fills a few of the sheet's columns, so keeping every empty one
        ("unnamed_1": null, ...) bloats the JSON and adds no information.
        Records left with nothing but _source_* metadata are dropped too.
        """
        import json as _json
        raw = _json.loads(df.to_json(orient="records", date_format="iso"))

        cleaned: List[Dict[str, Any]] = []
        for rec in raw:
            trimmed = {
                k: v for k, v in rec.items()
                if v is not None and not (isinstance(v, str) and not v.strip())
            }
            # Anything left that isn't bookkeeping?
            if any(not k.startswith("_") for k in trimmed):
                cleaned.append(trimmed)
        return cleaned

    @staticmethod
    def _clean_dataframe(
        df: pd.DataFrame, filename: str, sheet_name: Optional[str], title: Optional[str]
    ) -> pd.DataFrame:
        # Treat whitespace-only strings and the literal "nan"/"none"/"null"
        # text (common in exported sheets) as genuinely empty, so the
        # emptiness checks below actually catch them.
        df = df.replace(
            r"^\s*(?:nan|none|null|n/?a|-{1,2})?\s*$", pd.NA, regex=True
        )

        df = df.dropna(how="all").dropna(axis=1, how="all")

        df.columns = [
            "col_" + str(c).strip().lower().replace(" ", "_").replace("-", "_")
            if str(c) and str(c)[0].isdigit()
            else str(c).strip().lower().replace(" ", "_").replace("-", "_")
            for c in df.columns
        ]

        # pandas names header-less columns "Unnamed: 0", "Unnamed: 1"...
        # (they become "unnamed:_0" above). These are spacer columns from
        # the spreadsheet layout — drop them when they carry no data.
        drop_cols = [
            c for c in df.columns
            if str(c).startswith("unnamed") and df[c].isna().all()
        ]
        if drop_cols:
            df = df.drop(columns=drop_cols)

        # Deduplicate column names so records don't silently lose fields.
        seen: Dict[str, int] = {}
        new_cols = []
        for c in df.columns:
            if c in seen:
                seen[c] += 1
                new_cols.append(f"{c}_{seen[c]}")
            else:
                seen[c] = 0
                new_cols.append(c)
        df.columns = new_cols

        # Re-check emptiness after the replacements above, then drop any row
        # that is entirely empty (this runs BEFORE metadata columns are
        # added, so metadata can't keep a blank row alive).
        df = df.dropna(how="all")

        df["_source_file"] = filename
        if sheet_name:
            df["_source_sheet"] = sheet_name
        if title:
            df["_block_title"] = title

        # NOTE: previously this was `df[col].astype(str)`, which turned NaN
        # into the literal string "nan" — polluting output with fake values
        # that survived every emptiness check downstream. Keep nulls null.
        for col in df.select_dtypes(include=["object", "string"]).columns:
            df[col] = df[col].apply(
                lambda v: v if pd.isna(v) else str(v).strip()
            )

        return df


    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        import json
        try:
            clean = raw.strip()
            if clean.startswith("```"):
                clean = clean.lstrip("`")
                if clean.lower().startswith("json"):
                    clean = clean[4:]
                clean = clean.rstrip("`").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("[Excel] Could not parse Gemini JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}
