"""
main.py — Cloud Run Functions entry point

Triggered by Cloud Scheduler (HTTP GET) at 08:00 Europe/Dublin daily.

Deploy:
  gcloud functions deploy ingestion-pipeline \
    --gen2 \
    --runtime=python312 \
    --trigger-http \
    --entry-point=main \
    --region=europe-west1 \
    --memory=2Gi \
    --timeout=540s \
    --set-env-vars GCP_PROJECT_ID=your-project
"""

import json
import logging
import functions_framework
from flask import Request, jsonify

from utils.config_loader import load_config
from pipeline import IngestionPipeline

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


@functions_framework.http
def main(request: Request):
    """Single HTTP entry point for Cloud Run Functions."""
    path = request.path.rstrip("/")

    if path == "/health":
        return jsonify({"status": "ok"}), 200

    # Root or /run triggers a batch pass (Cloud Scheduler uses HTTP GET).
    # Previously a GET to the root path was swallowed by the health check,
    # so a scheduler pointed at the base URL never actually ran the pipeline.
    if path in ("/run", "") and request.method in ("GET", "POST"):
        limit = request.args.get("limit", type=int)          # ?limit=5
        dry_run = request.args.get("dry_run", "").lower() in ("1", "true")
        folder = request.args.get("folder")                  # ?folder=opp123
        force = request.args.get("force", "").lower() in ("1", "true")
        return _run_pipeline(
            limit=limit, dry_run=dry_run, folder=folder, force=force
        )

    return jsonify({"error": "Not found"}), 404


def _run_pipeline(limit=None, dry_run=False, folder=None, force=False):
    """Run a full batch pipeline pass."""
    try:
        cfg = load_config()
        pipeline = IngestionPipeline(cfg)
        results = pipeline.run(
            limit=limit, dry_run=dry_run, folder=folder, force=force
        )
        if results.get("status") == "locked":
            return jsonify(results), 409  # another run is in progress
        return jsonify(results), 200
    except Exception as exc:
        logger.exception("Pipeline failed: %s", exc)
        return jsonify({"error": str(exc)}), 500


if __name__ == "__main__":
    from utils.config_loader import load_config
    from pipeline import IngestionPipeline

    logging.basicConfig(level=logging.INFO)
    cfg = load_config()
    results = IngestionPipeline(cfg).run()
    print(json.dumps(results, indent=2))
