"""
pipeline.py — central router and orchestrator.

Production behaviors:
  - Run lock (GCS generation precondition) so an overlapping scheduled +
    manual run can never race on the state ledger.
  - State ledger v2: per-file object generation, attempt count, and status
    ("done" | "error" | "failed"). Legacy v1 ledgers (flat name->timestamp)
    are migrated transparently.
  - Change detection uses the GCS object *generation* (changes on every
    content overwrite), not just the updated timestamp.
  - Dead-lettering: a file that fails runtime.max_file_attempts times is
    parked with status "failed" and skipped until its content changes,
    instead of being retried (and re-billed) on every run forever.
  - Bounded parallelism (ThreadPoolExecutor) with a wall-clock budget so the
    Cloud Run Functions timeout never kills the process mid-write. Files
    that don't fit in the budget are deferred to the next run.
  - Incremental state persistence: after every batch and again in `finally`.

Flow:
  1. Optionally sync source bucket -> input bucket
  2. Acquire run lock
  3. List blobs, select pending (new / changed / retryable)
  4. Process in parallel batches, routing by extension
  5. Save outputs to GCS parsed_prefix, update ledger incrementally
  6. Release lock, return run summary
"""

import io
import logging
import mimetypes
import posixpath
import re
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote

from utils.config_loader import PipelineConfig
from utils.gcs_helper import GCSHelper
from utils.gemini_client import GeminiClient
from parsers.pdf_parser import PDFParser
from parsers.docx_parser import DOCXParser
from parsers.excel_parser import ExcelParser
from parsers.email_parser import EmailParser, Attachment
from parsers.image_parser import ImageParser
from parsers.pptx_parser import PPTXParser
from parsers.text_parser import TextParser
from parsers.visio_parser import VisioParser

logger = logging.getLogger(__name__)

STATE_VERSION = 2


class IngestionPipeline:
    def __init__(self, config: PipelineConfig):
        self.cfg = config

        # Shared GCS helper for destination bucket operations
        self.gcs = GCSHelper(
            config.gcs.destination_project_id or config.gcp.project_id
        )
        self.source_gcs = (
            GCSHelper(
                config.gcs.source_project_id or config.gcp.project_id
            )
            if config.gcs.source_bucket
            else None
        )

        self.gemini = GeminiClient(
            project_id=config.llm.project_id,
            location=config.gcp.location,
            proxy_url=config.llm.proxy_url,
            model_name=config.gemini.model,
            temperature=config.gemini.temperature,
            max_output_tokens=config.gemini.max_output_tokens,
        )

        # Extension -> parser type map (resolved from config)
        self._ext_map: Dict[str, str] = {}
        for parser_type, extensions in config.supported_extensions.items():
            for ext in extensions:
                self._ext_map[ext.lower()] = parser_type

    # ------------------------------------------------------------------ run

    def run(
        self,
        limit: Optional[int] = None,
        dry_run: bool = False,
        folder: Optional[str] = None,
        force: bool = False,
    ) -> Dict[str, Any]:
        """Execute one pipeline pass. Returns a run summary.

        limit:   cap the number of files processed this run (ops/testing).
        dry_run: list what *would* be processed without touching anything.
        folder:  restrict BOTH the sync and the parse to one subfolder,
                 relative to the configured source/input prefixes. e.g.
                 folder="opp123" syncs gs://<src>/<source_prefix>opp123/
                 into gs://<dst>/<input_prefix>opp123/ and parses only
                 that subtree. Output paths are unaffected — they still
                 land under <input_prefix><parsed_prefix>opp123/...
        force:   ignore ledger status and reprocess everything in scope,
                 even files already marked done. Costs LLM calls again —
                 pair with `folder` and/or `limit` unless you really mean
                 the whole bucket.
        """
        cfg = self.cfg
        bucket = cfg.gcs.destination_bucket
        run_id = uuid.uuid4().hex[:8]
        started = time.monotonic()
        deadline = started + cfg.runtime.max_runtime_seconds

        # "" for a full run, or "opp123/" for a scoped one. The trailing
        # slash matters: without it, "opp1" would also match "opp123".
        scope = folder.strip("/") + "/" if folder and folder.strip("/") else ""

        summary: Dict[str, Any] = {
            "run_id": run_id,
            "status": "ok",
            "processed": [],
            "errors": [],
            "deferred": [],
            "dead_lettered": [],
            "skipped_no_parser": [],
        }

        if force:
            summary["force"] = True
            logger.warning(
                "[%s] FORCE mode — reprocessing files already marked done",
                run_id,
            )
        if scope:
            summary["folder"] = scope
            logger.info("[%s] Scoped run — folder '%s' only", run_id, scope)

        if cfg.gcs.source_bucket and not dry_run:
            self._sync_source_bucket(
                source_bucket=cfg.gcs.source_bucket,
                source_prefix=cfg.gcs.source_prefix + scope,
                destination_bucket=bucket,
                destination_prefix=cfg.gcs.input_prefix + scope,
            )

        lock_blob = posixpath.join(
            posixpath.dirname(cfg.state_tracker_blob), "run.lock"
        )
        lock_acquired = False
        if not dry_run:
            lock_acquired = self.gcs.acquire_run_lock(
                bucket, lock_blob, cfg.runtime.lock_lease_seconds
            )
            if not lock_acquired:
                logger.warning(
                    "[%s] Another run holds the lock — exiting without work",
                    run_id,
                )
                summary["status"] = "locked"
                return summary

        try:
            state = self._migrate_state(
                self.gcs.load_state(bucket, cfg.state_tracker_blob)
            )
            files: Dict[str, Any] = state["files"]

            # Scoped runs list only the subfolder. _output_path and the
            # own-output filter still use the BASE input_prefix, so parsed
            # files land in the usual place regardless of scoping.
            blobs = self.gcs.list_blobs(bucket, cfg.gcs.input_prefix + scope)
            pending, dead, no_parser = self._select_pending(
                blobs, files, force=force
            )
            summary["dead_lettered"] = dead
            summary["skipped_no_parser"] = no_parser

            logger.info(
                "[%s] Ledger entries=%d, pending=%d, dead-lettered=%d",
                run_id, len(files), len(pending), len(dead),
            )

            if limit is not None:
                pending = pending[: max(0, int(limit))]

            if dry_run:
                summary["pending"] = [b.name for b in pending]
                return summary

            self._process_pending(
                pending, files, state, bucket, deadline, summary, lock_blob
            )
        finally:
            if lock_acquired:
                try:
                    self.gcs.save_state(bucket, cfg.state_tracker_blob, state)
                except Exception:
                    logger.exception(
                        "[%s] Final state save failed — some progress may "
                        "be reprocessed next run", run_id,
                    )
                self.gcs.release_run_lock(bucket, lock_blob)

        summary["duration_seconds"] = round(time.monotonic() - started, 1)
        logger.info(
            "[%s] Pipeline done — processed=%d errors=%d deferred=%d in %ss",
            run_id,
            len(summary["processed"]),
            len(summary["errors"]),
            len(summary["deferred"]),
            summary["duration_seconds"],
        )
        return summary

    def _process_pending(
        self,
        pending: List[Any],
        files: Dict[str, Any],
        state: Dict[str, Any],
        bucket: str,
        deadline: float,
        summary: Dict[str, Any],
        lock_blob: str,
    ) -> None:
        cfg = self.cfg
        max_workers = max(1, cfg.runtime.max_workers)

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            idx = 0
            while idx < len(pending):
                # Check the wall-clock budget *between* batches so we always
                # have time to persist state before Cloud Run kills us.
                if time.monotonic() >= deadline:
                    summary["deferred"] = [b.name for b in pending[idx:]]
                    logger.warning(
                        "Time budget (%ds) reached — deferring %d file(s) "
                        "to the next run",
                        cfg.runtime.max_runtime_seconds,
                        len(summary["deferred"]),
                    )
                    break

                batch = pending[idx: idx + max_workers]
                idx += len(batch)

                futures = {
                    pool.submit(self._process_blob, b.name, bucket): b
                    for b in batch
                }
                for fut in as_completed(futures):
                    blob = futures[fut]
                    prev = files.get(blob.name) or {}
                    try:
                        fut.result()
                        files[blob.name] = {
                            "generation": str(blob.generation),
                            "updated": blob.updated.isoformat(),
                            "processed_at": datetime.now(
                                timezone.utc
                            ).isoformat(),
                            "status": "done",
                            "attempts": 0,
                        }
                        summary["processed"].append(blob.name)
                        logger.info("✓ %s", blob.name)
                    except Exception as exc:
                        attempts = int(prev.get("attempts", 0)) + 1
                        exhausted = attempts >= cfg.runtime.max_file_attempts
                        files[blob.name] = {
                            "generation": str(blob.generation),
                            "updated": blob.updated.isoformat(),
                            "status": "failed" if exhausted else "error",
                            "attempts": attempts,
                            "last_error": str(exc)[:500],
                        }
                        summary["errors"].append(
                            {
                                "file": blob.name,
                                "attempt": attempts,
                                "error": str(exc),
                            }
                        )
                        if exhausted:
                            logger.error(
                                "✗ %s — attempt %d/%d failed, DEAD-LETTERED "
                                "until its content changes: %s",
                                blob.name, attempts,
                                cfg.runtime.max_file_attempts, exc,
                            )
                        else:
                            logger.exception("✗ %s — %s", blob.name, exc)

                # Persist after every batch: a crash/timeout must not lose
                # the record of files already (expensively) processed.
                self.gcs.save_state(bucket, cfg.state_tracker_blob, state)
                # Keep the lock lease fresh so a long run (e.g. backfill)
                # can't have its lock stolen as "stale" by a scheduled run.
                self.gcs.renew_run_lock(bucket, lock_blob)

    # ------------------------------------------------------- state handling

    @staticmethod
    def _migrate_state(raw: Dict[str, Any]) -> Dict[str, Any]:
        """Accept both ledger formats.

        v1: {"path/file.pdf": "<updated isoformat>", ...}
        v2: {"version": 2, "files": {"path/file.pdf": {...}, ...}}
        """
        if not raw:
            return {"version": STATE_VERSION, "files": {}}
        if raw.get("version") == STATE_VERSION and isinstance(
            raw.get("files"), dict
        ):
            return raw

        files: Dict[str, Any] = {}
        for name, value in raw.items():
            if isinstance(value, str):
                files[name] = {
                    "updated": value,
                    "status": "done",
                    "attempts": 0,
                }
            elif isinstance(value, dict):
                files[name] = value
        logger.info("Migrated %d ledger entries from v1 format", len(files))
        return {"version": STATE_VERSION, "files": files}

    def _select_pending(
        self, blobs: List[Any], files: Dict[str, Any], force: bool = False
    ) -> Tuple[List[Any], List[str], List[str]]:
        """Decide what to (re)process.

        Returns (pending_blobs, dead_lettered_names, no_parser_names):
          - never seen                      -> pending
          - content changed (generation)   -> pending (attempts reset)
          - status "error"                 -> pending (retry budget left)
          - status "failed", unchanged     -> dead-lettered, skipped
          - status "done", unchanged       -> skipped
        """
        pending: List[Any] = []
        dead: List[str] = []
        no_parser: List[str] = []
        product_code_skipped = 0

        # The pipeline's own outputs live under the parsed prefix inside the
        # input prefix — never report those as "skipped".
        own_output_prefix = (
            self.cfg.gcs.input_prefix + self.cfg.gcs.parsed_prefix
        )

        for b in blobs:
            if b.name.endswith("/"):
                continue
            if b.name.startswith(own_output_prefix):
                continue
            # Product Code folders are synced from the source bucket but
            # intentionally never parsed — they're pass-through data.
            if self._is_product_code_path(b.name):
                product_code_skipped += 1
                continue
            if self._extension(b.name) not in self._ext_map:
                no_parser.append(b.name)
                continue

            entry = files.get(b.name)
            if force:
                # Explicit re-parse: ignore "done"/"failed" status entirely.
                if isinstance(entry, dict):
                    entry["attempts"] = 0
                    files[b.name] = entry
                pending.append(b)
                continue
            if entry is None:
                pending.append(b)
                continue
            if isinstance(entry, str):  # defensive: unmigrated v1 value
                entry = {"updated": entry, "status": "done", "attempts": 0}

            if self._blob_changed(b, entry):
                logger.info("Content changed, reprocessing: %s", b.name)
                # New content: forget the old attempt count.
                entry["attempts"] = 0
                files[b.name] = entry
                pending.append(b)
            elif entry.get("status") == "error":
                pending.append(b)
            elif entry.get("status") == "failed":
                dead.append(b.name)
            # else: done & unchanged -> skip

        if product_code_skipped:
            logger.info(
                "Excluded %d file(s) in Product Code folders from parsing "
                "(sync-only)", product_code_skipped,
            )
        if no_parser:
            logger.warning(
                "%d file(s) skipped — no parser for their extension: %s",
                len(no_parser), ", ".join(no_parser[:20]),
            )

        return pending, dead, no_parser

    @staticmethod
    def _is_product_code_path(blob_name: str) -> bool:
        """True if any *folder* segment of the path is a Product Code
        folder. Matching is deliberately liberal: case-insensitive, tolerant
        of URL-encoding and separators — so 'ProductCode', 'Product Code',
        'Product%20Code', 'product_codes', 'PRODUCT-CODE' all match.
        A file merely *named* product_code.xlsx in a normal folder does not.
        """
        for segment in blob_name.split("/")[:-1]:  # folders only
            norm = re.sub(r"[^a-z0-9]", "", unquote(segment).lower())
            if "product" in norm and "code" in norm:
                return True
        return False

    @staticmethod
    def _blob_changed(blob: Any, entry: Dict[str, Any]) -> bool:
        stored_gen = entry.get("generation")
        if stored_gen:
            return str(blob.generation) != str(stored_gen)
        # Legacy entries only have the updated timestamp.
        return blob.updated.isoformat() != entry.get("updated")

    # ------------------------------------------------------------- routing

    def _process_blob(self, blob_name: str, bucket: str) -> None:
        ext = self._extension(blob_name)
        parser_type = self._ext_map.get(ext)
        filename = PurePosixPath(blob_name).name

        logger.info("Processing [%s] %s", parser_type, blob_name)
        file_bytes = self.gcs.download_bytes(bucket, blob_name)
        self._route(parser_type, file_bytes, filename, blob_name, bucket)

    def _route(
        self,
        parser_type: Optional[str],
        file_bytes: bytes,
        filename: str,
        blob_name: str,
        bucket: str,
        zip_depth: int = 0,
    ) -> None:
        """Single dispatch point used for top-level blobs, email
        attachments, and zip archive entries alike."""
        if parser_type == "pdf":
            self._handle_pdf(file_bytes, filename, blob_name, bucket)
        elif parser_type == "docx":
            self._handle_docx(file_bytes, filename, blob_name, bucket)
        elif parser_type == "excel":
            self._handle_excel(file_bytes, filename, blob_name, bucket)
        elif parser_type == "email":
            self._handle_email(file_bytes, filename, blob_name, bucket)
        elif parser_type == "image":
            self._handle_image(
                file_bytes, filename, blob_name, bucket,
                self._guess_mime(filename),
            )
        elif parser_type == "text":
            self._handle_text(file_bytes, filename, blob_name, bucket)
        elif parser_type == "pptx":
            self._handle_pptx(file_bytes, filename, blob_name, bucket)
        elif parser_type == "visio":
            self._handle_visio(file_bytes, filename, blob_name, bucket)
        elif parser_type == "archive":
            self._handle_zip(
                file_bytes, filename, blob_name, bucket, depth=zip_depth
            )
        else:
            logger.warning(
                "No parser for '%s' — skipping %s", filename, blob_name
            )

    # ---- archives ------------------------------------------------------

    MAX_ZIP_DEPTH = 2          # zip inside zip is the limit
    MAX_ZIP_ENTRIES = 500      # per archive
    MAX_ENTRY_BYTES = 100 * 1024 * 1024  # per uncompressed entry

    def _handle_zip(
        self,
        file_bytes: bytes,
        filename: str,
        blob_name: str,
        bucket: str,
        depth: int = 0,
    ) -> None:
        """Extract a zip and route every contained file through its own
        parser. Outputs land under <zipname>_extracted/<inner path> in the
        parsed prefix. If any entry fails, the zip as a whole is treated as
        failed so the ledger's retry/dead-letter semantics apply to it
        (re-runs are idempotent — successful entries just overwrite)."""
        import zipfile

        if depth >= self.MAX_ZIP_DEPTH:
            logger.warning(
                "[Zip] %s exceeds max nesting depth (%d) — not extracting",
                blob_name, self.MAX_ZIP_DEPTH,
            )
            return

        archive_root = posixpath.join(
            posixpath.dirname(blob_name),
            PurePosixPath(filename).name + "_extracted",
        )
        failures: List[str] = []
        routed = 0

        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            entries = [i for i in zf.infolist() if not i.is_dir()]
            if len(entries) > self.MAX_ZIP_ENTRIES:
                logger.warning(
                    "[Zip] %s has %d entries — only the first %d are processed",
                    blob_name, len(entries), self.MAX_ZIP_ENTRIES,
                )
                entries = entries[: self.MAX_ZIP_ENTRIES]

            for info in entries:
                inner = info.filename
                base = posixpath.basename(inner)
                if inner.startswith("__MACOSX/") or base.startswith("."):
                    continue
                if info.file_size > self.MAX_ENTRY_BYTES:
                    logger.warning(
                        "[Zip] Skipping oversized entry %s (%d bytes) in %s",
                        inner, info.file_size, blob_name,
                    )
                    continue

                ptype = self._ext_map.get(self._extension(inner))
                virtual_blob = posixpath.join(archive_root, inner)
                if ptype is None:
                    logger.warning(
                        "[Zip] No parser for entry %s in %s — skipped",
                        inner, blob_name,
                    )
                    continue

                logger.info("  [Zip entry:%s] %s", ptype, inner)
                try:
                    self._route(
                        ptype, zf.read(info), base, virtual_blob, bucket,
                        zip_depth=depth + 1,
                    )
                    routed += 1
                except Exception as exc:
                    logger.exception(
                        "  [Zip entry] %s in %s failed: %s",
                        inner, blob_name, exc,
                    )
                    failures.append(f"{inner}: {exc}")

        logger.info(
            "[Zip] %s — %d entrie(s) parsed, %d failed",
            blob_name, routed, len(failures),
        )
        if failures:
            raise RuntimeError(
                f"{len(failures)} entrie(s) failed inside {filename}: "
                + "; ".join(failures[:5])
            )

    def _handle_pdf(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = PDFParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

    def _handle_text(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = TextParser()
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

    def _handle_docx(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = DOCXParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

    def _handle_excel(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = ExcelParser(
            gemini=self.gemini,
            max_cells_for_gemini=self.cfg.excel.max_cells_for_gemini,
        )
        summary = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, "_extracted.json")
        self.gcs.upload_json(bucket, out_path, summary)

    def _handle_email(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = EmailParser(self.gemini)
        result, attachments = parser.parse(file_bytes, filename)

        # Save email extraction
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

        # Route attachments recursively through their own parsers
        for att in attachments:
            try:
                self._process_attachment(att, blob_name, bucket)
            except Exception as exc:
                logger.warning(
                    "Attachment %s from %s failed: %s",
                    att.filename, filename, exc,
                )

    def _handle_image(
        self,
        file_bytes: bytes,
        filename: str,
        blob_name: str,
        bucket: str,
        mime_type: str,
    ) -> None:
        parser = ImageParser(self.gemini)
        result = parser.parse(
            image_bytes=file_bytes,
            filename=filename,
            mime_type=mime_type,
        )
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

    def _handle_pptx(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = PPTXParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

    def _handle_visio(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = VisioParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self.gcs.upload_json(bucket, out_path, result)

    @staticmethod
    def _ignore_attachment(filename: str) -> bool:
        return "logo" in filename.lower()

    def _process_attachment(
        self, att: Attachment, parent_blob: str, bucket: str
    ) -> None:
        """Route an email attachment to the correct parser."""
        if self._ignore_attachment(att.filename):
            logger.info("    Skipping logo attachment %s", att.filename)
            return

        ext = self._extension(att.filename)
        parser_type = self._ext_map.get(ext)

        # Virtual blob name for output path calculation. Namespaced by the
        # SOURCE EMAIL — a shared "attachments/" folder per directory meant
        # same-named attachments (invoice.pdf, image001.png) from different
        # emails silently overwrote each other.
        virtual_blob = posixpath.join(
            posixpath.dirname(parent_blob),
            PurePosixPath(parent_blob).name + "_attachments",
            att.filename,
        )

        logger.info("    Attachment [%s] %s", parser_type, att.filename)
        self._route(parser_type, att.data, att.filename, virtual_blob, bucket)

    # --------------------------------------------------------------- utils

    def _output_path(self, blob_name: str, new_suffix: str) -> str:
        """
        Put parsed output in a parsed_prefix subfolder alongside the input.

        The FULL original filename (extension included) is kept in the
        output name, because stripping it caused silent overwrites:
        report.pdf, report.docx and report.msg all used to map to the same
        report.json — last (parallel!) writer won.

        e.g.  test/oop1/invoices/inv001.pdf
                -> test/oop1/parsed_files/invoices/inv001.pdf.json
              test/oop1/invoices/inv001.xlsx
                -> test/oop1/parsed_files/invoices/inv001.xlsx_extracted.json
        """
        cfg = self.cfg.gcs
        rel = blob_name[len(cfg.input_prefix):]  # strip leading prefix
        return cfg.input_prefix + cfg.parsed_prefix + rel + new_suffix

    def _sync_source_bucket(
        self,
        source_bucket: str,
        source_prefix: str,
        destination_bucket: str,
        destination_prefix: str,
    ) -> None:
        """Copy new/updated objects from the source bucket into the input bucket."""
        source_prefix = source_prefix or ""
        destination_prefix = destination_prefix or ""

        logger.info(
            "Syncing source bucket gs://%s/%s into gs://%s/%s",
            source_bucket,
            source_prefix or "(root)",
            destination_bucket,
            destination_prefix or "(root)",
        )

        if self.source_gcs is None:
            raise RuntimeError("Source GCS helper is not configured")

        self.source_gcs.copy_blobs(
            source_bucket,
            source_prefix,
            destination_bucket,
            destination_prefix,
        )

    @staticmethod
    def _guess_mime(filename: str) -> str:
        return mimetypes.guess_type(filename)[0] or "application/octet-stream"

    @staticmethod
    def _extension(name: str) -> str:
        return ("." + name.rsplit(".", 1)[-1]).lower() if "." in name else ""
