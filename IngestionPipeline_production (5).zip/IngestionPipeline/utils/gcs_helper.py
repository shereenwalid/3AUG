"""gcs_helper.py — thin wrapper around google-cloud-storage"""

import json
import logging
import posixpath
from datetime import datetime, timezone
from typing import List, Optional

from google.cloud import storage
from google.api_core.exceptions import NotFound, PreconditionFailed

logger = logging.getLogger(__name__)


class GCSHelper:
    def __init__(self, project_id: str):
        self.client = storage.Client(project=project_id)

    # ------------------------------------------------------------ run lock

    def acquire_run_lock(
        self, bucket_name: str, blob_name: str, lease_seconds: int = 900
    ) -> bool:
        """Atomically acquire a run lock.

        Creating the blob with if_generation_match=0 succeeds only if it
        doesn't already exist — GCS guarantees atomicity, so two concurrent
        runs (scheduler + manual trigger) can never both proceed. A crashed
        run's lock is stolen after lease_seconds.
        """
        bucket = self.client.bucket(bucket_name)
        payload = json.dumps(
            {"acquired_at": datetime.now(timezone.utc).isoformat()}
        ).encode()

        for _ in range(2):  # one retry after stealing / vanishing lock
            blob = bucket.blob(blob_name)
            try:
                blob.upload_from_string(
                    payload,
                    content_type="application/json",
                    if_generation_match=0,
                )
                logger.info("Acquired run lock gs://%s/%s", bucket_name, blob_name)
                return True
            except PreconditionFailed:
                existing = bucket.get_blob(blob_name)
                if existing is None:
                    continue  # released between our calls — try again
                age = (
                    datetime.now(timezone.utc) - existing.updated
                ).total_seconds()
                if age <= lease_seconds:
                    logger.warning(
                        "Run lock gs://%s/%s held for %.0fs — another run "
                        "is in progress",
                        bucket_name, blob_name, age,
                    )
                    return False
                logger.warning(
                    "Stealing stale run lock (age %.0fs > lease %ds) — "
                    "previous run likely crashed",
                    age, lease_seconds,
                )
                try:
                    existing.delete(if_generation_match=existing.generation)
                except (PreconditionFailed, NotFound):
                    return False  # someone else stole it first
        return False

    def renew_run_lock(self, bucket_name: str, blob_name: str) -> None:
        """Refresh the lock's timestamp. Called periodically during a run so
        a long backfill (hours) can't be mistaken for a crashed run and have
        its lock stolen by a scheduled invocation."""
        try:
            payload = json.dumps(
                {"renewed_at": datetime.now(timezone.utc).isoformat()}
            ).encode()
            self.client.bucket(bucket_name).blob(blob_name).upload_from_string(
                payload, content_type="application/json"
            )
        except Exception:
            logger.exception(
                "Failed to renew run lock gs://%s/%s", bucket_name, blob_name
            )

    def release_run_lock(self, bucket_name: str, blob_name: str) -> None:
        try:
            self.client.bucket(bucket_name).blob(blob_name).delete()
            logger.info("Released run lock gs://%s/%s", bucket_name, blob_name)
        except NotFound:
            pass
        except Exception:
            logger.exception(
                "Failed to release run lock gs://%s/%s — it will expire "
                "after the lease period",
                bucket_name, blob_name,
            )



    def list_blobs(self, bucket_name: str, prefix: str) -> List[storage.Blob]:
        """Return all blobs under *prefix* (non-recursive would need delimiter)."""
        bucket = self.client.bucket(bucket_name)
        return list(bucket.list_blobs(prefix=prefix))


    def copy_blobs(
        self,
        source_bucket_name: str,
        source_prefix: str,
        destination_bucket_name: str,
        destination_prefix: str = "",
    ) -> None:
        """Copy only new or updated objects."""

        source_prefix = source_prefix or ""
        destination_prefix = destination_prefix or ""

        blobs = self.list_blobs(source_bucket_name, source_prefix)

        source_bucket = self.client.bucket(source_bucket_name)
        destination_bucket = self.client.bucket(destination_bucket_name)

        for blob in blobs:

            if blob.name.endswith("/"):
                continue

            rel_name = (
                blob.name[len(source_prefix):]
                if source_prefix and blob.name.startswith(source_prefix)
                else blob.name
            )

            dest_blob_name = posixpath.join(
                destination_prefix,
                rel_name,
            )

            dest_blob = destination_bucket.get_blob(dest_blob_name)

            # File does not exist yet
            if dest_blob is None:
                source_bucket.copy_blob(
                    blob,
                    destination_bucket,
                    dest_blob_name,
                )

                logger.info(
                    "Copied new file gs://%s/%s -> gs://%s/%s",
                    source_bucket_name,
                    blob.name,
                    destination_bucket_name,
                    dest_blob_name,
                )
                continue

            # Only copy if source is newer
            if blob.updated > dest_blob.updated:

                source_bucket.copy_blob(
                    blob,
                    destination_bucket,
                    dest_blob_name,
                )

                logger.info(
                    "Updated file gs://%s/%s -> gs://%s/%s",
                    source_bucket_name,
                    blob.name,
                    destination_bucket_name,
                    dest_blob_name,
                )

    def download_bytes(self, bucket_name: str, blob_name: str) -> bytes:
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(blob_name)
        return blob.download_as_bytes()


    def upload_bytes(
        self,
        bucket_name: str,
        blob_name: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(blob_name)
        blob.upload_from_string(data, content_type=content_type)
        logger.info("Uploaded %s bytes > gs://%s/%s", len(data), bucket_name, blob_name)

    def upload_json(
        self, bucket_name: str, blob_name: str, payload: dict
    ) -> None:
        self.upload_bytes(
            bucket_name,
            blob_name,
            json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"),
            content_type="application/json",
        )



    def load_state(self, bucket_name: str, blob_name: str) -> dict:
        """Load the processed-files ledger.

        Only a missing blob means "fresh start". Any other failure
        (permissions, network, corrupt JSON) raises — silently returning {}
        would cause a full, expensive reprocess of every file.
        """
        try:
            raw = self.download_bytes(bucket_name, blob_name)
        except NotFound:
            logger.info(
                "State blob gs://%s/%s not found — first run, starting fresh",
                bucket_name, blob_name,
            )
            return {}

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            logger.exception(
                "State blob gs://%s/%s exists but is not valid JSON — "
                "refusing to silently reprocess everything. Fix or delete it.",
                bucket_name, blob_name,
            )
            raise



    def save_state(
    self, bucket_name: str, blob_name: str, processed: dict
    ) -> None:
        self.upload_bytes(
            bucket_name,
            blob_name,
            json.dumps(processed, indent=2).encode(),
            content_type="application/json",
        )
