"""
Product Code Navigator - BigQuery lookup tools.

Resolves a tech-spec product (producer/stock code + description) to a final
BSP item code, returned as "code-name/desc", with a confidence level.

Search cascade (stops at the first hit):
  1. TEMP_PM by Supplier_Part_Number  LIKE %code%   -> Supplier_Part_Number - Material_Description
  2. TEMP_item_model by producer_code LIKE %code%    -> producer_code - name
  3. (no code) TEMP_item_model by name LIKE %desc%    -> producer_code - name

Confidence:
  - exact code/desc match in TEMP_PM          -> High
  - exact code/desc match in TEMP_item_model  -> Medium
  - only a similar (LIKE) match anywhere      -> Low

Recency: an item must be seen within the last 2 years. raw_item_model has
item_model_id + delivery_date; we build the set of recent item_model_ids and
keep only matches whose id is in that set (best effort - if recency cannot be
resolved, the match is still returned but flagged not-recency-checked).
"""

import difflib
from datetime import datetime, timedelta

# Reuse the BigQuery client + dataset resolution from the main Agent tools.
try:
    from ...Agent.tools import _bq, _bq_table, _rows_to_dicts
except Exception:  # noqa: BLE001 - fallback if run standalone
    from vf_quote_to_order_agent_configured.Agent.tools import (  # type: ignore
        _bq, _bq_table, _rows_to_dicts,
    )

from google.adk.tools import ToolContext

RECENCY_YEARS = 2


# ─────────────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────────────
def _norm(s) -> str:
    return (str(s or "")).strip().upper()


def _similar(a, b) -> float:
    return difflib.SequenceMatcher(None, _norm(a), _norm(b)).ratio()


def _recent_item_model_ids():
    """Return a set of item_model_id values whose delivery_date is within the
    last RECENCY_YEARS. All columns are strings, so we parse defensively.
    Returns None if the recency table can't be read (so callers don't hard-fail).
    """
    table = _bq_table("raw_item_model")
    cutoff = datetime.utcnow() - timedelta(days=365 * RECENCY_YEARS)
    try:
        rows = _rows_to_dicts(
            _bq().query(f"SELECT item_model_id, delivery_date FROM {table}"),
            limit=10_000_000,
        )
    except Exception:  # noqa: BLE001
        return None

    recent = set()
    for r in rows:
        mid = r.get("item_model_id")
        dd = r.get("delivery_date")
        if not mid or not dd:
            continue
        parsed = None
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y/%m/%d", "%m/%d/%Y",
                    "%Y-%m-%d %H:%M:%S", "%d-%m-%Y"):
            try:
                parsed = datetime.strptime(str(dd).strip()[:19], fmt)
                break
            except ValueError:
                continue
        if parsed is None:
            # unparseable date -> treat as recent (don't discard silently)
            recent.add(str(mid))
            continue
        if parsed >= cutoff:
            recent.add(str(mid))
    return recent


def _best_row(rows, code, desc):
    """Pick the row most similar to (code, desc)."""
    def score(r):
        vals = " ".join(str(v) for v in r.values())
        return max(_similar(vals, code), _similar(vals, desc))
    return max(rows, key=score) if rows else None


def _has_exact(rows, code, desc, fields):
    """True if any row has an exact (normalized) match of code or desc in the
    given candidate fields."""
    tc, td = _norm(code), _norm(desc)
    for r in rows:
        for f in fields:
            val = _norm(r.get(f))
            if val and (val == tc or (td and val == td)):
                return True
    return False


def _apply_recency(rows, recent_ids):
    """Keep only rows whose item_model_id is in recent_ids (if we could build
    that set and the rows actually carry an id). Returns (kept, recency_checked).
    """
    if recent_ids is None:
        return rows, False
    id_field = None
    for cand in ("item_model_id", "item_model_ID", "id"):
        if rows and cand in rows[0]:
            id_field = cand
            break
    if not id_field:
        return rows, False
    kept = [r for r in rows if str(r.get(id_field)) in recent_ids]
    return (kept if kept else rows), True


# ─────────────────────────────────────────────────────────────────────
# the tool
# ─────────────────────────────────────────────────────────────────────
def resolve_product_code(product_stock_code: str, description: str,
                         tool_context: ToolContext) -> dict:
    """Resolve a tech-spec product to its final BSP item code.

    Args:
        product_stock_code: The producer / supplier / stock code from the tech
            spec. Pass "" if none is available.
        description: The item (stock) description from the tech spec.

    Returns:
        dict with:
          resolved: "<code> - <name/desc>"  (always this shape)
          code, name, confidence ("High"|"Medium"|"Low"|"None"),
          source_table, recency_checked, candidates_considered
    """
    from google.cloud import bigquery

    code = (product_stock_code or "").strip()
    desc = (description or "").strip()
    recent_ids = _recent_item_model_ids()

    def run(table_key, where_col, value):
        table = _bq_table(table_key)
        sql = f"SELECT * FROM {table} WHERE UPPER(`{where_col}`) LIKE @v"
        cfg = bigquery.QueryJobConfig(query_parameters=[
            bigquery.ScalarQueryParameter("v", "STRING", f"%{value.upper()}%")
        ])
        try:
            return _rows_to_dicts(_bq().query(sql, job_config=cfg), limit=100)
        except Exception as exc:  # noqa: BLE001
            print(f"[PCNAV ERROR] {table} on {where_col} LIKE %{value}%: "
                  f"{type(exc).__name__}: {exc}")
            return {"__error__": f"{type(exc).__name__}: {exc}"}

    # ---- 1. TEMP_PM by Supplier_Part_Number (only if we have a code) ----
    if code:
        rows = run("TEMP_PM", "Supplier_Part_Number", code)
        if isinstance(rows, dict) and rows.get("__error__"):
            return {"status": "error", "message": rows["__error__"],
                    "resolved": f"{code} - {desc}", "confidence": "None"}
        rows, checked = _apply_recency(rows, recent_ids)
        if rows:
            exact = _has_exact(rows, code, desc,
                               ["Supplier_Part_Number", "Material_Description"])
            best = _best_row(rows, code, desc)
            c = best.get("Supplier_Part_Number") or code
            n = best.get("Material_Description") or desc
            return _result(c, n, "High" if exact else "Low", "TEMP_PM",
                           checked, len(rows))

    # ---- 2. TEMP_item_model by producer_code (only if we have a code) ----
    if code:
        rows = run("TEMP_item_model", "producer_code", code)
        if isinstance(rows, dict) and rows.get("__error__"):
            return {"status": "error", "message": rows["__error__"],
                    "resolved": f"{code} - {desc}", "confidence": "None"}
        rows, checked = _apply_recency(rows, recent_ids)
        if rows:
            exact = _has_exact(rows, code, desc, ["producer_code", "name"])
            best = _best_row(rows, code, desc)
            c = best.get("producer_code") or code
            n = best.get("name") or desc
            return _result(c, n, "Medium" if exact else "Low",
                           "TEMP_item_model", checked, len(rows))

    # ---- 3. no code (or nothing found by code): TEMP_item_model by name ----
    if desc:
        rows = run("TEMP_item_model", "name", desc)
        if isinstance(rows, dict) and rows.get("__error__"):
            return {"status": "error", "message": rows["__error__"],
                    "resolved": f"{code} - {desc}", "confidence": "None"}
        rows, checked = _apply_recency(rows, recent_ids)
        if rows:
            exact = _has_exact(rows, code, desc, ["producer_code", "name"])
            best = _best_row(rows, code, desc)
            c = best.get("producer_code") or code
            n = best.get("name") or desc
            return _result(c, n, "Medium" if exact else "Low",
                           "TEMP_item_model", checked, len(rows))

    # ---- nothing found: echo the tech-spec values, no confidence ----
    return _result(code, desc, "None", None, recent_ids is not None, 0)


def _result(code, name, confidence, source, recency_checked, considered):
    return {
        "status": "success",
        "resolved": f"{code} - {name}",   # always code-name/desc
        "code": code,
        "name": name,
        "confidence": confidence,          # High | Medium | Low | None
        "source_table": source,
        "recency_checked": recency_checked,
        "candidates_considered": considered,
    }
