"""
Product Code Navigator agent.

Runs in parallel with the validation agent. It is scoped to the TECH SPEC
ONLY: the retrieval node loads the tech-spec-only view into shared session
state as "tech_spec_data" (a dict containing ONLY the file(s) whose name
matched the tech spec pattern - every other opportunity document, e.g. PO,
signed contract, customer/vendor quotes, HLD, site details, is deliberately
excluded from what this agent sees). It never reads the full
"opportunity_data" state. For every product line found in the tech spec it
resolves the FINAL BSP item code via BigQuery, returning "code - name/desc"
plus a confidence level.

Its output (session state key "resolved_product_codes") is consumed by the BSP
extraction agent (which is likewise scoped to "tech_spec_data" only) to fill
each order row's Item and Confidence columns.
"""

# Reuse the same proxy-backed model the root agents use.
try:
    from ...Agent.agent import gemini_model
except Exception:  # noqa: BLE001
    gemini_model = None

from google.adk import Agent

from .tools import resolve_product_code


PRODUCT_CODE_PROMPT = """
You are the Product Code Navigator.

SCOPE - READ THIS FIRST:
You work from the TECH SPEC document(s) ONLY. You are given ONLY the tech
spec content below - no PO, no signed contract, no customer/vendor quotes,
no HLD, no other opportunity document. Those other files are out of scope
for you; they are used by the validation agent only. If the tech spec is
missing or empty, report that instead of pulling data from anywhere else.

Tech spec file(s) for this opportunity: {tech_spec_files?}

Tech-spec-only document content (your ONLY knowledge base):
{tech_spec_data?}

STEP 1 - Confirm the TECH SPEC content above is present. If {tech_spec_data?}
         is empty or missing, return an empty "resolved_codes" list and stop -
         do not attempt to source product codes from elsewhere.
STEP 2 - From the tech spec, list EVERY product/service line. For each one,
         read its PRODUCT STOCK CODE (a.k.a. producer / supplier code) and its
         ITEM (stock) DESCRIPTION. Some lines may have only a description.
STEP 3 - For EACH product line, call the tool `resolve_product_code` with:
           product_stock_code = the code (or "" if none)
           description        = the item description
         Call it once per product line. Do not guess codes yourself.

The tool returns the resolved final code as "code - name/desc" plus a
confidence (High / Medium / Low / None). Use exactly what the tool returns -
never invent or alter a code.

Return ONLY this JSON object (no markdown, no commentary):
{
  "resolved_codes": [
    {
      "product_stock_code": "<what you read from the tech spec, or ''>",
      "description": "<what you read from the tech spec>",
      "resolved": "<code - name/desc, exactly from the tool>",
      "confidence": "High|Medium|Low|None"
    }
  ]
}
"""

product_code_agent = Agent(
    model=gemini_model,
    name="product_code_agent",
    mode="single_turn",
    description="Resolves tech-spec products to final BSP item codes with confidence.",
    instruction=PRODUCT_CODE_PROMPT,
    tools=[resolve_product_code],
    output_key="resolved_product_codes",
)
