"""View 3: Validation - exact markup from validationPage.html (sidebar removed,
buttons: Return to Order Entry + Proceed to Order Creation). Items rendered by JS."""


def view() -> str:
    return """
    <div id="view-validation" style="display:none;">
      <main class="flex-1 pt-4 p-4 md:px-6 md:pb-6 flex flex-col gap-4 mx-auto w-full" style="max-width:1400px; font-family:'Hanken Grotesk',sans-serif;">
        <header class="flex flex-col md:flex-row justify-between items-start md:items-end gap-3 border-b border-surface-variant pb-4 mt-2 md:mt-0 shrink-0">
          <div>
            <h2 class="text-[28px] font-bold text-on-background">Delivery Service Transition Acceptance Validation</h2>
            <p class="font-body-md text-sm text-secondary mt-1" id="val-opp-subtitle">Opportunity ID: -</p>
          </div>
          <div class="flex gap-2">
            <button onclick="resetToLanding()"
               class="px-4 py-1.5 bg-primary-container text-white font-button rounded hover:bg-primary transition-colors flex items-center gap-2 text-sm">
              <span class="material-symbols-outlined">keyboard_return</span>
              Return to Order Entry
            </button>
            <button onclick="showSection('results')"
               class="px-4 py-1.5 bg-tertiary-container text-white font-button rounded hover:bg-tertiary transition-colors flex items-center gap-2 text-sm">
              <span class="material-symbols-outlined">arrow_forward</span>
              Proceed to Order Creation
            </button>
          </div>
        </header>

        <div id="val-banner"></div>

        <div class="flex items-center gap-2 shrink-0">
          <span class="font-label-sm text-[10px] text-secondary uppercase tracking-wider">Order Category</span>
          <span id="val-order-category"
                class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-sidebar-dark text-white text-[10px] uppercase font-bold tracking-wider">
            <span class="material-symbols-outlined text-[13px]">category</span>
            <span id="val-order-category-text">-</span>
          </span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 shrink-0">
          <section class="bg-surface-container-lowest rounded-xl border border-surface-variant p-0 overflow-hidden flex flex-col">
            <div class="bg-inverse-surface p-3 border-b border-outline/30 shrink-0">
              <h3 class="text-[16px] leading-tight text-white font-semibold">Criteria Checklist</h3>
            </div>
            <div class="p-0 overflow-y-auto max-h-[640px]" style="scrollbar-width:thin; scrollbar-color:#b70100 #f3f3f3;">
              <ul class="flex flex-col" id="val-criteria-list"></ul>
            </div>
          </section>
          <section class="bg-surface-container-lowest rounded-xl border border-surface-variant p-0 overflow-hidden flex flex-col">
            <div class="bg-inverse-surface p-3 border-b border-outline/30 shrink-0">
              <h3 class="text-[16px] leading-tight text-white font-semibold">Checks</h3>
            </div>
            <div class="p-0 overflow-y-auto max-h-[640px]" style="scrollbar-width:thin; scrollbar-color:#b70100 #f3f3f3;">
              <ul class="flex flex-col" id="val-checks-list"></ul>
            </div>
          </section>
        </div>

        <section class="bg-surface-container-low rounded-xl border border-surface-variant p-4 mt-2 shrink-0">
          <h4 class="text-[16px] text-on-background mb-1 flex items-center gap-2 font-semibold">
            <span class="material-symbols-outlined text-secondary text-[18px]">help</span>Guidance
          </h4>
          <p class="font-body-md text-sm text-on-surface-variant max-w-4xl" id="val-guidance"></p>
        </section>
      </main>
    </div>
    """
