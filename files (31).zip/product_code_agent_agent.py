"""
Product Code Navigator agent.

Runs in parallel with the validation agent. Reads the tech spec (already loaded
into shared session state as "opportunity_data" by the retrieval node), and for
every product line resolves the FINAL BSP item code via BigQuery, returning
"code - name/desc" plus a confidence level.

Its output (session state key "resolved_product_codes") is consumed by the BSP
extraction agent to fill each order row's Item and Confidence columns.
"""

# Reuse the same proxy-backed model the root agents use.
try:
    from ...Agent.agent import gemini_model
except Exception:  # noqa: BLE001
    gemini_model = None

from google.adk import Agent

from .tools import resolve_product_code


PRODUCT_CODE_PROMPT = """
You are the Product Code Navigator.

The opportunity's parsed documents are in session state:
{opportunity_data?}

STEP 1 - Find the TECH SPEC document (tech_spec_files: {tech_spec_files?}).
STEP 2 - From the tech spec ONLY, list EVERY product/service line. For each
         one, read its PRODUCT STOCK CODE (a.k.a. producer / supplier code)
         and its ITEM (stock) DESCRIPTION. Some lines may have only a
         description.
STEP 3 - For EACH product line, call the tool `resolve_product_code` with:
           product_stock_code = the code (or "" if none)
           description        = the item description
         Call it once per product line. Do not guess codes yourself.

TECH SPEC ONLY - HARD RULE:
Every product_stock_code / description you pass to `resolve_product_code`
MUST come from the TECH SPEC document, and nowhere else.
- The other documents in {opportunity_data?} (PO, customer quote, vendor
  quote, circuit order form, HLD, email, etc.) are there ONLY to support the
  separate validation step. NEVER read a product stock code or description
  out of one of them and pass it to this tool - not even if the tech spec
  looks incomplete or a code seems easier to find elsewhere.
- If the tech spec has no product lines, or is missing, call the tool for
  nothing and return "resolved_codes": [].
- The tool itself will also reject anything it doesn't recognize as
  originating from the tech spec, so there is no benefit to trying codes
  from elsewhere - only the tech spec's own lines will ever resolve.

The tool returns the resolved final code as "code - name/desc" plus a
confidence (High / Medium / Low / None). Use exactly what the tool returns -
never invent or alter a code.

SELF-CHECK BEFORE YOU RETURN (do this silently, do not show your work):
For every entry you are about to return, confirm its product_stock_code or
description text actually appears in the tech spec document you read. If you
cannot point to where in the tech spec it came from, remove that entry.

Return ONLY this JSON object (no markdown, no commentary):
{
  "resolved_codes": [
    {
      "product_stock_code": "<what you read from the tech spec, or ''>",
      "description": "<what you read from the tech spec>",
      "resolved": "<code - name/desc, exactly from the tool>",
      "confidence": "High|Medium|Low|None"
    }
  ]
}
"""

product_code_agent = Agent(
    model=gemini_model,
    name="product_code_agent",
    mode="single_turn",
    description="Resolves tech-spec products to final BSP item codes with confidence.",
    instruction=PRODUCT_CODE_PROMPT,
    tools=[resolve_product_code],
    output_key="resolved_product_codes",
)
